# Lab 04
setwd("C:\\Users\\ASUS\\OneDrive\\Desktop\\Lab04")

# PART A 
# 1.
dataset <- read.table("DATA 4.txt", header=TRUE)
head(dataset)
str(dataset)

# 2(a)
boxplot(dataset$X1, main="Boxplot of Attendance")
boxplot(dataset$X2, main="Boxplot of Salary")
boxplot(dataset$X3, main="Boxplot of Years")

hist(dataset$X1, main="Histogram of Attendance", xlab="Attendance")
hist(dataset$X2, main="Histogram of Salary", xlab="Salary")
hist(dataset$X3, main="Histogram of Years", xlab="Years")

stem(dataset$X1)
stem(dataset$X2)
stem(dataset$X3)

# 2(b)
mean(dataset$X1); median(dataset$X1); sd(dataset$X1)
mean(dataset$X2); median(dataset$X2); sd(dataset$X2)
mean(dataset$X3); median(dataset$X3); sd(dataset$X3)

# 2(c)
quantile(dataset$X1, probs=c(0.25,0.75))
quantile(dataset$X2, probs=c(0.25,0.75))
quantile(dataset$X3, probs=c(0.25,0.75))

# 2(d)
IQR(dataset$X1)
IQR(dataset$X2)
IQR(dataset$X3)

# 3.
get_mode <- function(v) {
  uniq_vals <- unique(v)
  uniq_vals[which.max(tabulate(match(v, uniq_vals)))]
}

get_mode(dataset$X3)

# 4.
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_val <- Q3 - Q1
  lower <- Q1 - 1.5 * IQR_val
  upper <- Q3 + 1.5 * IQR_val
  outliers <- x[x < lower | x > upper]
  return(outliers)
}
find_outliers(dataset$X1)
find_outliers(dataset$X2)
find_outliers(dataset$X3)

# PART B 
# 1.
branch_data <- read.csv("Exercise.txt", header=TRUE)
head(branch_data)
str(branch_data)

# 2.
# Branch - Identifier (Nominal)
# Sales_X1 - Ratio
# Advertising_X2 - Ratio
# Years_X3 - Ratio

# 3.
boxplot(branch_data$Sales_X1, main="Boxplot of Sales", ylab="Sales")

# 4.
fivenum(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

# 5.
find_outliers(branch_data$Years_X3)

